/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase03;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Seguimos viendo tipos de datos primitivos
        
        //boolean - ocupa 1 byte y almacena 2 valores (0 y 1)
        //que representan true y false
        boolean l = true; //representa el valor de verdad
        boolean m = false; //representa el valor de falso
        System.out.println(l);
        System.out.println(m);
        
        //char ocupa 2 bytes, almacena un entero que representa
        //un caracter de la tabla unicode
        //unicode es un standard de codificación de caracteres a nivel
        //mundial
        char n = 65; //almacena el entero 65
        //pero representa un caracter de la tabla unicode
        System.out.println(n);
        n += 32;
        System.out.println(n);
        //también puedo almacenar un caracter directamente
        n = 'f'; // los caracteres se escriben entre comillas simples
        System.out.println(n);
        n -= 32;
        System.out.println(n);
        
        //String - no es un tipo de dato primitivo
        //representa una cadena de caracteres
        String o = "Hola"; //se escribe con S mayúscula
        //el valor va dentro de comillas dobles
        System.out.println(o);
        String p = "Hola, soy una cadena de caracteres & . 45";
        System.out.println(p);
        
        /*
        Convenciones de escritura
        es una frase en camel case
        camel case = estoEsUnaFraseEnCamelCase
        pascal case = EstoEsUnaFraseEnCamelCase
        snake case = esto_es_una_frase_en_camel_case
        */
        
        //Constantes
        //son similares a las variables
        //almacenan un dato en memoria con un identificador
        //y un tipo de dato
        //pero no cambian su valor
        final double PI=3.14; 
        System.out.println(PI);
        //las constantes deben llevar la palabra reservada final
        //y el nombre de la constante va en mayúscula por convención
        
        //Tipos de datos var
        //en este tipo de datos el verdadero tipo de dato asignado
        //va a estar dado por la literal
        
        var var1 = 100; //lo guarda como un int
        var var2 = 'c'; //char
        var var3 = "c"; //String
        var var4 = 5.25f; //float
        
        
        
    }
    
}
