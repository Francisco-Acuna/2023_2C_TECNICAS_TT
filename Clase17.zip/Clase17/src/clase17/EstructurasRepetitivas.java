

package clase17;

import java.util.Scanner;


public class EstructurasRepetitivas {
    public static void main(String[] args) {
        
        //bucles - estructuras repetitivas
        System.out.println("**Estructura while**");
        
        //la estructura while, evalúa una condición y mientras sea
        //verdadera, ejecuta las sentencias del cuerpo del while
        
        //imprimir los números del 1 al 10 uno debajo del otro.
        int contador = 1;
        
        while(contador <= 10){
            System.out.println(contador);
            contador++;
        }
        
        contador = 1;
        //ERROR - bucle infinito
//        while (contador <= 10) {
//            System.out.println(contador);
//        }
        
//        while (contador >= 1) {
//            System.out.println(contador);
//            contador++;
//        }
        
        System.out.println("** Estructura do-while **");
        
        //La estructura do-while ejecuta al menos una vez las sentencias
        //y luego evalúa la condición para seguir ejecutando
        
        //sumamos los números positivos ingresados por teclado
        int numero = 0;
        int suma = 0;
        Scanner teclado = new Scanner(System.in);
        
//        do{
//            System.out.println("Ingrese un número entero para sumar"
//                    + " ó 0 para salir");
//            numero = teclado.nextInt();
//            if(numero>0) suma+=numero;
//        }while(numero!=0);
//        
//        System.out.println("Usted ingresó un 0 para salir.");
//        System.out.println("La suma de los números enteros positivos"
//                + " es de: "+suma);
        
        System.out.println("** Sentencia break **");
        
        //La sentencia break genera un corte en la secuencia
        //de comandos y saca la ejecución del bloque de código
        
        //siguiendo el ejemplo anterior, si la suma supera
        //los 100, vamos a cortar la ejecución.
//        suma=0;
//        do{
//            System.out.println("Ingrese un número entero para sumar"
//                    + " ó 0 para salir");
//            numero = teclado.nextInt();
//            if(numero>0) suma+=numero;
//            if(suma>100) break;
//        }while(numero!=0);
        
        System.out.println("La suma de números enteros "
                + "positivos es de: "+suma);
        
       
        System.out.println("** Sentencia continue **");
        
        //La sentencia continue genera un corte en la secuencia
        //de comandos y vuelve al comienzo del bucle
        
        //continuando con nuestro ejemplo, ahora sólo sumaremos
        //los números pares
        suma=0;
        do{
            System.out.println("Ingrese un número entero para sumar"
                    + " ó 0 para salir");
            numero = teclado.nextInt();
            if(numero%2!=0) continue;
            if(numero>0) suma+=numero;
            if(suma>100) break;
        }while(numero!=0);
        
        System.out.println("La suma de números enteros positivos pares es de: "+suma);
        
        System.out.println("** Estructura for **");
        
        //La estructura for es una estructura repetitiva
        
        //imprimir los números del 1 al 10 uno debajo del otro
        
        for(int i=1; i<=10; i++){
            System.out.println(i);
        }
        
        System.out.println("***********************");
        
        //si sólo ejecutamos una instrucción del for,
        //lo podemos hacer en línea
        for(int i=1; i<=10; i++) System.out.println("Hola Mundo!!");
        
        //La variable que está dentro del for es una variable local.
        //Sólo se utiliza dento del for, no tiene alcance (scope) fuera de
        //la estructura. Al terminar el bucle for, desaparece. Se 
        //destruye y deja de ocupar lugar en memoria.
        
        System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&");
        //imprimir los números del 1 al 10
        //sin imprimir los números 2, 5 y 9
        for(int i=1; i<=10; i++){
            if(i!=2 && i!=5 && i!=9) System.out.println(i);
        }
        
        
        
        
    }
}
