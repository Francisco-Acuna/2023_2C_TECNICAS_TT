

package clase21;

import java.util.Scanner;


public class Ejercicios {
    public static void main(String[] args) {
        
        /*
        Crear un programa que tenga un m�todo al cual se le ingrese una frase
        como par�metro y luego imprima por consola la misma frase repetida 
        7 veces, una debajo de otra
        */    
        Scanner teclado = new Scanner(System.in);
        String frase = "Hola Mundo!!";
        System.out.println("Ingrese la frase que se repetir� 7 veces");
        retornarFrase7Veces(teclado.nextLine());
        
        /*
        Crear un programa que reciba 3 par�metros y calcule la suma, resta, 
        multiplicaci�n, divisi�n y resto de dos n�meros con decimales.
        Las consignas para lograrlo son:
        * Crear un m�todo que no retorne nada, que reciba los 3 par�metros
        (2 n�meros decimales y un caracter de operaci�n)
        * Crear los m�todos de las operaciones que retorne un n�mero con decimales
        * Mostrar por consola un mensaje que indique el resultado y la operaci�n
        realizada.
        */
        System.out.println(dividir(12, 0));
        
        System.out.println("Ingrese un n�mero y luego presione enter.");
        float nro1 = teclado.nextFloat();
        System.out.println("Ingrese el segundo n�mero y luego presione enter.");
        float nro2 = teclado.nextFloat();
        System.out.println("Ingrese el s�mbolo de una operaci�n matem�tica y luego presione enter.");
        String operacion = teclado.next();
        
        realizarOperacion(nro1, nro2, operacion);
    }
    
    public static void retornarFrase7Veces(String frase){
        for (int i = 1; i <7; i++) {
            System.out.println(frase);
        }
    }
    
    public static void realizarOperacion(float numero1, float numero2, String operador){
        switch(operador){
            case "+": System.out.println("La suma de los n�meros es "+sumar(numero1, numero2)); break;
            case "-": System.out.println("La resta de los n�meros es "+restar(numero1, numero2)); break;
            case "*": System.out.println("La multiplicaci�n de los n�meros es "+multiplicar(numero1, numero2)); break;
            case "/": 
                if(numero2==0){
                    System.out.println("No es posible realizar la divisi�n por cero");
                    break;
                }else{
                    System.out.println("La divisi�n de los n�meros es "+dividir(numero1, numero2)); break;
                } 
            case "%": System.out.println("El resto de los n�meros es "+obtenerResto(numero1, numero2)); break;
            default: System.out.println("Opci�n no v�lida.");
        }
    }
    
    public static float sumar(float numero1, float numero2){
        return numero1+numero2;
    }
    
    public static float restar(float numero1, float numero2){
        return numero1 - numero2;
    }
    
    public static float multiplicar(float numero1, float numero2){
        return numero1 * numero2;
    }
    
    public static float dividir(float numero1, float numero2){
        return numero1 / numero2;
    }
    
    public static float obtenerResto(float numero1, float numero2){
        return numero1 % numero2;
    }
    
}
