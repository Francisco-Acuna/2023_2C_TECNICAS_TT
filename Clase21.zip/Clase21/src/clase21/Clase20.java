
package clase21;

import java.util.Scanner;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase20 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
        Una persona desea invertir $1000 en un banco, el
        cual le otorga un 2% de inter�s mensual �Cu�l
        ser� la cantidad de dinero que esta persona
        tendr� al cabo de un a�o?
        En el primer mes tendr� acumulado 1000 $ m�s
        20 $ de inter�s ( 2% de 1000 ). En el segundo
        mes se le sumar� un 2% a la base de 1020 $ del
        mes anterior y as� sucesivamente. 
        */
        
//        double interes = 2;
//        double interesAcumulado =0;
//        double capital = 1000;
//        int mes = 1;
//        
//        for(int i=1; i<=12;i++){
//            System.out.println("Su capital inicial en este mes es de: $"+Math.round(capital));
//            System.out.println("El inter�s en el mes "+mes+" es del %"+interes);
//            double interesMensual = capital / 100 * interes;
//            interesAcumulado += interesMensual;
//            System.out.println("Que representa una ganancia de $"+Math.round(interesMensual));
//            System.out.println("---------------------------------------------");
//            capital += interesMensual;   
//            mes++;
//        }
//        
//        System.out.println("Su capital final es de $"+Math.round(capital));
//        System.out.println("Su ganancia total en este a�o fue de: "+Math.round(interesAcumulado));
//        
//        System.out.println("################################");
//        /*
//        Crear un programa que ingrese una oraci�n y
//        muestre cu�l es el caracter que m�s se repite.
//        Consideraciones:
//        * No se debe contar el espacio en blanco.
//        * La oraci�n a ingresar no debe estar vac�a.
//        */
//        Scanner teclado = new Scanner(System.in);
//        String oracion = "";
//        
//        //utilizar bucle do-while para asegurarnos de que
//        //se ingrese una oraci�n que no est� vac�a
//        do {
//            System.out.println("Ingrese una oraci�n. La misma no puede estar vac�a.");
//            oracion = teclado.nextLine();
//            if(oracion.isBlank()) System.out.println("Por favor la oraci�n no puede estar vac�a.");
//        } while (oracion.isBlank());
//        
//        //le damos un valor inicial con el primer caracter
//        //de la oraci�n a la variable que lo va a guardar
//        char caracterMasRepetido = oracion.charAt(0);
//        int cantidadDeRepeticiones = 0;
//        
//        for(int i=0; i<oracion.length(); i++){
//            //almacenar en una variable el caracter actual del recorrido
//            char caracter = oracion.charAt(i);
//            
//            //ignoramos los espacios en blanco
//            if(caracter == ' ') continue;
//            
//            //creamos un contador parcial
//            int recuento = 1;
//            
//            //contar cu�ntas veces se repite el caracter
//            for(int j=i+1; j<oracion.length();j++){
//                if(oracion.charAt(j) == caracter) recuento++;
//            }
//            
//            //comprobar si es el caracter que m�s se repite
//            if(recuento > cantidadDeRepeticiones){
//                cantidadDeRepeticiones = recuento;
//                caracterMasRepetido = caracter;
//            }
//
//        }
//        
//        System.out.println("El caracter que m�s se repite "
//                + "sin contar los espacios. Es:\'"+caracterMasRepetido
//                + "\' que se repite "+cantidadDeRepeticiones+" veces.");
//        
//        System.out.println("*** Funciones y Procedimientos ***");
        
        /*
        Las funciones y procedimientos son un bloque de c�digo
        que contienen una o m�s instrucciones, al cual podemos
        invocar para que sean ejecutadas. Las funciones y los
        procedimientos nos van a ayudar a hacer nuestro c�digo
        m�s legible y evitar c�digo duplicado.
        */
        
        /*
        Los m�todos de tipo funci�n siempre retornan un valor.
        En su declaraci�n deben indicar qu� tipo de valor retornan.
        En su cuerpo deben contener la sentencia 'return' con el
        retorno del tipo de dato que se indic� en su cabecera.
        */
        System.out.println("** Funciones **");
        int nro1 = retornarNumeroDiez();
//        int nro1 = 10; esto es lo mismo que lo anterior
        System.out.println(nro1);
        System.out.println(retornarNumeroDiez());
        
        
        int nro2 = 30;
        int resultado = sumarDosEnteros(nro1, nro2);
        System.out.println(resultado);
        System.out.println(sumarDosEnteros(17, 5));
        
        System.out.println(esPar(retornarNumeroDiez()));
        
        
        System.out.println("** Procedimientos **");
        
        /*
        Los m�todos de tipo procedimiento no tienen un retorno.
        En su declaraci�n deben tener la palabra reservada void,
        para indicar que no tienen retorno.
        */
        
        saludar();
        String usuario = "Julio";
        saludarConNombre(usuario);
        saludarConNombre("Julia");
        
        float baseRectangulo = 12.5f;
        float alturaRectangulo = 7.28f;
        
        calcularAreaRectangulo(baseRectangulo, alturaRectangulo);
        
        sumarParImpar(7, retornarNumeroDiez(), usuario);
        
        /*
        Crear un programa que tenga un m�todo al cual se le ingrese una frase
        como par�metro y luego imprima por consola la misma frase repetida 
        7 veces, una debajo de otra
        */
        
        /*
        Crear un programa que reciba 3 par�metros y calcule la suma, resta, 
        multiplicaci�n, divisi�n y resto de dos n�meros con decimales.
        Las consignas para lograrlo son:
        * Crear un m�todo que no retorne nada, que reciba los 3 par�metros
        (2 n�meros decimales y un caracter de operaci�n)
        * Crear los m�todos de las operaciones que retorne un n�mero con decimales
        * Mostrar por consola un mensaje que indique el resultado y la operaci�n
        realizada.
        */
        
    } // final del m�todo main
    
    //ejemplos de funciones
    public static int retornarNumeroDiez(){
        return 10;  //el return tiene que devolver
        //el mismo tipo de dato que se indica en la
        //firma del m�todo.   
    }
    
    public static int sumarDosEnteros(int numero1, int numero2){
        //esta funci�n recibe 2 par�metros
        //los par�metros son los valores de entrada.
        //se deben indicar, primero el tipo de dato y luego el identificador
        //el identificador es a nivel de referencia, cuando llamamos al m�todo
        //no es necesario que tengan el mismo identificador, pero s� el mismo
        //tipo de dato
        return numero1 + numero2;
    }
    
    public static boolean esPar(int numero){
//        if(numero%2 == 0){
//            return true;
//        }else {
//            return false;
//        }
        return numero%2 == 0;      
    }
    
    //Ejemplos de procedimientos
    public static void saludar(){
        System.out.println("Hola Mundo!!");
    }
    
    public static void saludarConNombre(String nombre){
        System.out.println("Hola "+nombre+" !!");
    }
    
    /**
     * Este m�todo informa el �rea de un rect�ngulo
     * @param base es la base del rect�ngulo
     * @param altura es la altura del rect�ngulo
     */
    public static void calcularAreaRectangulo(float base, float altura){
        float area = base * altura;
        System.out.println("El area del rect�ngulo es: "+area);
    }
    
    //m�todos dentro de m�todos
    public static void sumarParImpar(int numero1, int numero2, String nombre){
        saludarConNombre(nombre);
        if(esPar(sumarDosEnteros(numero1, numero2))){
            System.out.println("La suma es par!!");
        }else {
            System.out.println("La suma es impar.");
        }
    }
    
    
    
    
} // final de la clase
