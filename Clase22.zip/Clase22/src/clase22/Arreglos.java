

package clase22;


public class Arreglos {
    public static void main(String[] args) {
        //Si tuvi�ramos que almacenar varios n�meros enteros:
        int variable1 = 145;
        int variable2 = 34;
        int variable3 = 12;
        
        /*
        Pero en vez de declarar tantas variables, lo que
        podemos hacer es generar un vector o arreglo que 
        agrupe a todas las variables dentro de un mismo
        conjunto y bajo un mismo nombre.
        Podemos acceder a cada elemento por medio del 
        �ndice. Los �ndices comienzan en 0 y finalizan en
        la �ltima posici�n representada por la longitud -1
        De esta manera optimizamos la lectura de la informaci�n
        para acceder por un mismo nombre a distintas variables
        y no por el nombre de cada una de ellas.
        */
        
        System.out.println("Arrays, arreglos y vectores");
        
        /*
        Declaraci�n:
        tipoDeDato[] identificador; --> declaraci�n
        tipoDeDato identificador[]; --> declaraci�n
        identificador = new tipoDeDato[n]; --> cantidad de variables que va a tener
        */
        
        float[] temperaturas; //declaraci�n de arreglo o vector
        temperaturas = new float[10]; //indicamos la longitud del arreglo
        float temperaturas2[] = new float[12];
        String nombres[] = new String[5];
        
        //asignaci�n de valores a las variables de un arreglo
        temperaturas[0] = 25.32f;
        temperaturas[1] = 12.56f;
//        temperaturas[2] = "Jose"; la literal no respeta el mismo tipo de dato

        nombres[3] = "Juan";
//        nombres[5] = "Lucas"; error, no existe la posici�n de �ndice 5

        //leer contenido de un sub�ndice
        System.out.println(temperaturas[0]);
        System.out.println(nombres[3]);
        System.out.println(nombres[4]); //devuelve null porque no hay dato guardado
        
        //inicializaci�n
        int[] numeros = {12, 59, 87, 129, 0};
        // posici�n --->  0   1   2   3   4
        //declaraci�n e inicializaci�n de un vector con 5 elementos
        
        //mostrar el contenido de un arreglo
        System.out.println(numeros); //no muestra el contenido
        //muestra la posici�n de memoria del vector. Porque el nombre es una
        //referencia, no es el contenido.
        
        System.out.println("\nContenido del arreglo");
        System.out.println(numeros[0]); 
        System.out.println(numeros[1]); 
        System.out.println(numeros[2]); 
        System.out.println(numeros[3]); 
        System.out.println(numeros[4]); 
        
        System.out.println("\nRecorrido del contenido por contador o referencia:");
        int contador=0;
        System.out.println(numeros[contador]);
        contador++;
        System.out.println(numeros[contador]);
        contador++;
        System.out.println(numeros[contador]);
        contador++;
        System.out.println(numeros[contador]);
        contador++;
        System.out.println(numeros[contador]);
        
        
        System.out.println("\nRecorrido del contenido con for");
        for (int i=0; i<5; i++) {
            System.out.println(numeros[i]);
        }
        
        System.out.println("\nRecorrido del contenido con for informando el �ndice");
        for (int i=0; i<5; i++) {
            System.out.println("El valor de la posici�n "+i+" es "+numeros[i]);
        }
        
        //longitud de un vector
        System.out.println("\nLongitud del vector");
        //el atributo length muestra la longitud del vector
        System.out.println(numeros.length);
        
        System.out.println("\nRecorrido con for utilizando length");
        for (int i=0; i<numeros.length; i++) {
            System.out.println(numeros[i]);
        }
        
        //copias de arreglos
        //declaramos un arreglo de origen
        char[] origen = {'a', 'b', 'c', 'x', '@'};
        
        //creamos un arreglo de destino con la misma longitud que el arreglo de origen
        char[] destino = new char[origen.length];
        
        //recorremos los arreglos:
        System.out.println("Arreglo de origen:");
        for (int i=0; i<origen.length; i++) {
            System.out.print(origen[i]+" ");
        }
        
        System.out.println("\nArreglo de destino:");
        for (int i=0; i<destino.length; i++) {
            System.out.print(destino[i]+" ");
        }
        System.out.println("");
        
    }
}
