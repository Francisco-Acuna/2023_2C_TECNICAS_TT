

package curso.tecnicas.entidades;


public class CalculadoraLogica {
    public static double calcular(double primerNumero, double segundoNumero, char operador){
        double resultado = 0;
        switch(operador){
            case '+': resultado = primerNumero + segundoNumero; break;
            case '-': resultado = primerNumero - segundoNumero; break;
            case '*': resultado = primerNumero * segundoNumero; break;
            case '/': resultado = primerNumero / segundoNumero;
        }
        return resultado;
    }
}
