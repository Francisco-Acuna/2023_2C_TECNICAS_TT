/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase13;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //condicionales
        
        System.out.println("**Estructura if**");
        
        int nro1 = 10;
        int nro2 = 50;
        
        if (nro1 > nro2) {
            System.out.println("El nro1 es mayor al nro2.");
        }
        System.out.println("Fin de la estructura if.");
        
        
        if (nro1 == 20) {
            System.out.println("El nro1 es igual a 20");
            //al ser falsa la condición, esta línea no se ejecuta
        }
        
        
        if (nro1 != 20) {
            System.out.println("El nro1 es distinto a 20.");
        }
        
        
        boolean log1 = false;
        
        if (!log1) { //no se compara con == true (es redundante)
            System.out.println("Log1 es verdadera");
        }
        
        //se puede escribir en una sola línea si sólo se ejecuta una sentencia
        if (nro1 < nro2) System.out.println("El nro1 es menor al nro2.");
        
        if (nro1 == 10 && !log1) System.out.println("Ejecuto una sola sentencia");
        
        
        //si ejecutamos más de una sentencia o instrucción, debemos poner las llaves
        if (nro1 != 100) {
            nro1 += 20;
            System.out.println(nro1);
        }
        
        System.out.println("**Estructura if-else**");
        
        if (nro1 > nro2){
            System.out.println("El nro1 es mayor al nro2.");
        } else {
            System.out.println("El nro1 no es mayor que el nro2.");
        }
        
        //También se puede escribir en línea, sin llaves
        //si sólo se ejecuta una única condición.
        if (19 > 2) System.out.println("El primer número es mayor que el segundo");
        else System.out.println("El primer número no es mayor que el segundo");
        
        /*
        Ejercicio
        dado un usuario="pepito" y una contraseña="1234"
        Informar:
        si ingresó bien ambos datos: "Bienvenido pepito!!"
        de lo contrario: "ERROR - credenciales incorrectas"
        */
        
        String usuario = "pepito";
        String clave = "1234";
        
        if (usuario.equals("pepito") && clave.equals("1234")){
            System.out.println("Bienvenido pepito!!");
        } else {
            System.out.println("ERROR - credenciales incorrectas");
        }
        
        System.out.println("**Estructura if-else if-else**");
        
        //determinar cuál de los dos números es el mayor
        nro1 = 100;
        nro2 = 300;
        
        if (nro1 > nro2){
            System.out.println("El nro1 es el mayor.");
        } else if (nro2 > nro1){
            System.out.println("El nro2 es el mayor.");
        } else {
            System.out.println("Ambos números son iguales.");
        }
        
        int edad = 60;
        String genero = "femenino";
        
        if (edad >= 65 && genero.equals("masculino")){
            System.out.println("Se puede jubilar");
        } else if (edad >= 60 && genero.equals("femenino")){
            System.out.println("Se puede jubilar");
        } else {
            System.out.println("No se puede jubilar.");
        }
        
        if (edad >= 65 && genero.equals("masculino") || edad >= 60 && genero.equals("femenino")){
            System.out.println("Se puede jubilar.");
        } else {
            System.out.println("No se puede jubilar.");
        }
        
        System.out.println("**if-else anidado**");
         //teniendo 3 números distintos, determinar cuál es el mayor
         
         nro1 = 30;
         nro2 = 10;
         int nro3 = 50;
        
         if (nro1 > nro2){
             if (nro1 > nro3){
                 System.out.println("El nro1 es el mayor.");
             } else {
                 System.out.println("El nro3 es el mayor.");
             }
         }else if (nro2 > nro3){
             System.out.println("El nro2 es el mayor.");
         } else {
             System.out.println("El nro3 es el mayor.");
         }
        
        boolean tienePasaporte = true;
        edad = 18;
        
        if (tienePasaporte){
            if (edad >= 18){
                System.out.println("Puede viajar solo");
            } else {
                System.out.println("Puede viajar, pero acompañado");
            }
        } else {
            System.out.println("No puede viajar.");
        }
        
        /*
        Ejercicio1:
        según la edad de una persona, mostraremos los siguientes mensajes:
        menos de 12 años: eres un niño
        entre 12 y 17 años: eres un adolescente
        entre 18 y 39: eres joven
        entre 40 y 70: eres maduro
        de 71 para arriba: eres anciano
        */
        
        /*
        Ejercicio2:
        Dada la siguiente tabla del tiempo, hacer un programa que indique
        qué puede hacer una persona con dicho pronóstico:
        
        Temperatura     Tiempo      Sugerencia
        > 25º           soleado     caminar y tomar sol
        > 15º y <=25º   soleado     caminar
        <= 15º          soleado     caminar con campera
        < 10º           lluvia      quedarse en casa o salir con paraguas y campera
        < 10º           nieve       esquiar
        */
        
        /*
        Ejercicio3:
        Solicitar al usuario que ingrese 3 números. 2 positivos y 1 negativo
        (en cualquier orden).
        Luego, informar por pantalla la multiplicación de los números 
        que son positivos
        */
    }
    
}
