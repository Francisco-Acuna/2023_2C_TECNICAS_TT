/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package objetosclase1;

import objetosclase1.entidades.Auto;
import objetosclase1.entidades.Empleado;

/**
 *
 * @author Aula 8 - Docente
 */
public class ObjetosClase1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Auto auto1 = new Auto();
        
        auto1.marca = "Ford";
        auto1.modelo = "Ka";
        auto1.color = "negro";
        auto1.velocidad = 0;
        
        System.out.println(auto1.marca);
        System.out.println(auto1.modelo);
        System.out.println(auto1.color);
        System.out.println(auto1.velocidad);
        
        Auto auto2 = new Auto("Chevrolet", "Corsa", "Blanco", 0);
        System.out.println(auto2.marca);
        System.out.println(auto2.modelo);
        System.out.println(auto2.color);
        System.out.println(auto2.velocidad);
        
        Auto auto3 = new Auto("Citroen", "c3", "Azul");
        System.out.println(auto3.marca);
        System.out.println(auto3.modelo);
        System.out.println(auto3.color);
        System.out.println(auto3.velocidad);
        
        Auto auto4 = new Auto("Fiesta", "P�rpura");
        System.out.println(auto4.marca);
        System.out.println(auto4.modelo);
        System.out.println(auto4.color);
        System.out.println(auto4.velocidad);
        
        System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&\n");
        System.out.println(auto1.velocidad);
        auto1.acelerar();
        System.out.println(auto1.velocidad);
        for(int i=0; i<5; i++){
            auto1.acelerar();
        }
        System.out.println(auto1.velocidad);
        auto1.frenar();
        auto1.frenar();
        System.out.println(auto1.velocidad);
        
        auto1.acelerar(100);
        System.out.println(auto1.velocidad);
        
        auto1.acelerar(200, false);
        System.out.println(auto1.velocidad);
        
        System.out.println(auto1);
        System.out.println(auto2);
        
        System.out.println("\n***************************\n");
        
        Empleado empleado1 = new Empleado(1, "Esteban", "Quito", "soltero", 120000);
        
        System.out.println(empleado1.getNombre());
        System.out.println(empleado1.getApellido());
        
        empleado1.setNombre("Max");
        empleado1.setApellido("Power");
        
        System.out.println(empleado1.getNombre());
        System.out.println(empleado1.getApellido());
        
        empleado1.setSueldoBasico(980000);
        
        System.out.println(empleado1);
        
    }
    
}
