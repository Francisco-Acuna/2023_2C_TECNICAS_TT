

package objetosclase1.entidades;


public class Empleado {
    //Atributos
    private int id;
    private String nombre;
    private String apellido;
    private String estadoCivil;
    private double sueldoBasico;

    public Empleado(int id, String nombre, String apellido, String estadoCivil, double sueldoBasico) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.estadoCivil = estadoCivil;
        this.sueldoBasico = sueldoBasico;
    }

    @Override
    public String toString() {
        return "Empleado{" + "id=" + id + ", nombre=" + nombre + ", apellido=" + apellido + ", estadoCivil=" + estadoCivil + ", sueldoBasico=" + sueldoBasico + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    public double getSueldoBasico() {
        return sueldoBasico;
    }

    public void setSueldoBasico(double sueldoBasico) {
        if(sueldoBasico <= 200000) this.sueldoBasico = sueldoBasico;
        else System.out.println("No puede pasar el l�mite de $200.000");
    }
    
    

}
