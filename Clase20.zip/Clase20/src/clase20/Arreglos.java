

package clase20;


public class Arreglos {
    public static void main(String[] args) {
        //Si tuvi�ramos que almacenar varios n�meros enteros:
        int variable1 = 145;
        int variable2 = 34;
        int variable3 = 12;
        
        /*
        Pero en vez de declarar tantas variables, lo que
        podemos hacer es generar un vector o arreglo que 
        agrupe a todas las variables dentro de un mismo
        conjunto y bajo un mismo nombre.
        Podemos acceder a cada elemento por medio del 
        �ndice. Los �ndices comienzan en 0 y finalizan en
        la �ltima posici�n representada por la longitud -1
        De esta manera optimizamos la lectura de la informaci�n
        para acceder por un mismo nombre a distintas variables
        y no por el nombre de cada una de ellas.
        */
    }
}
