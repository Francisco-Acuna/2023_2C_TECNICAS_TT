/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase11;

import java.util.Scanner;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*
        Solicitar al usuario que ingrese 3 números.
        Luego informar:
        a) La suma de los dos primeros
        b) La resta de los dos segundos
        c) El resto entre el primero y el segundo
        d) La suma total
        e) El promedio
        */
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Por favor, ingrese 3 números enteros.");
        System.out.println("A continuación ingrese el primero y luego presione enter:");
        int num1 = teclado.nextInt();
        System.out.println("A continuación ingrese el segundo y luego presione enter:");
        int num2 = teclado.nextInt();
        System.out.println("A continuación ingrese el tercero y luego presione enter:");
        int num3 = teclado.nextInt();
        
        int suma = num1 + num2;
        int resta = num2 - num3;
        int resto = num1 % num2;
        int total = suma + num3;
        int promedio = total / 3;
        
        System.out.println("La suma de los dos primeros números es "+suma);
        System.out.println("La resta de los dos segundos números es "+resta);
        System.out.println("El resto del primer y segundo número es "+resto);
        System.out.println("La suma total es de "+total);
        System.out.println("El promedio es de "+promedio);
        
        
        /*
        Solicitar al usario que ingrese dos números.
        Devolver el primer número aumentado en 17
        y el segundo número decrementado en 10
        */
        
        System.out.println("Por favor, ingrese dos números enteros (sin decimales)");
        System.out.println("A continuación ingrese el primer número y presione enter:");
        num1 = teclado.nextInt();
        System.out.println("A continuación ingrese el segundo número y presione enter:");
        num2 = teclado.nextInt();
        
//        int aumento = num1 + 17;
//        int decremento = num2 - 10;
        
//        System.out.println("El primer número es "+num1);
//        System.out.println("El primer número aumentado en 17 es "+aumento);
         num1 += 17;
         num2 -= 10;
         
         System.out.println("El primer número aumentado en 17 es "+num1);
         System.out.println("El primer número decrementado en 10 es "+num2);
        
    }
    
}
