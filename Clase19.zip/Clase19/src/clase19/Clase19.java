
package clase19;

import java.util.Scanner;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase19 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
        Una persona desea invertir $1000 en un banco, el
        cual le otorga un 2% de inter�s mensual �Cu�l
        ser� la cantidad de dinero que esta persona
        tendr� al cabo de un a�o?
        En el primer mes tendr� acumulado 1000 $ m�s
        20 $ de inter�s ( 2% de 1000 ). En el segundo
        mes se le sumar� un 2% a la base de 1020 $ del
        mes anterior y as� sucesivamente. 
        */
        
        double interes = 2;
        double interesAcumulado =0;
        double capital = 1000;
        int mes = 1;
        
        for(int i=1; i<=12;i++){
            System.out.println("Su capital inicial en este mes es de: $"+Math.round(capital));
            System.out.println("El inter�s en el mes "+mes+" es del %"+interes);
            double interesMensual = capital / 100 * interes;
            interesAcumulado += interesMensual;
            System.out.println("Que representa una ganancia de $"+Math.round(interesMensual));
            System.out.println("---------------------------------------------");
            capital += interesMensual;   
            mes++;
        }
        
        System.out.println("Su capital final es de $"+Math.round(capital));
        System.out.println("Su ganancia total en este a�o fue de: "+Math.round(interesAcumulado));
        
        System.out.println("################################");
        /*
        Crear un programa que ingrese una oraci�n y
        muestre cu�l es el caracter que m�s se repite.
        Consideraciones:
        * No se debe contar el espacio en blanco.
        * La oraci�n a ingresar no debe estar vac�a.
        */
        Scanner teclado = new Scanner(System.in);
        String oracion = "";
        
        //utilizar bucle do-while para asegurarnos de que
        //se ingrese una oraci�n que no est� vac�a
        do {
            System.out.println("Ingrese una oraci�n. La misma no puede estar vac�a.");
            oracion = teclado.nextLine();
            if(oracion.isBlank()) System.out.println("Por favor la oraci�n no puede estar vac�a.");
        } while (oracion.isBlank());
        
        //le damos un valor inicial con el primer caracter
        //de la oraci�n a la variable que lo va a guardar
        char caracterMasRepetido = oracion.charAt(0);
        int cantidadDeRepeticiones = 0;
        
        for(int i=0; i<oracion.length(); i++){
            //almacenar en una variable el caracter actual del recorrido
            char caracter = oracion.charAt(i);
            
            //ignoramos los espacios en blanco
            if(caracter == ' ') continue;
            
            //creamos un contador parcial
            int recuento = 1;
            
            //contar cu�ntas veces se repite el caracter
            for(int j=i+1; j<oracion.length();j++){
                if(oracion.charAt(j) == caracter) recuento++;
            }
            
            //comprobar si es el caracter que m�s se repite
            if(recuento > cantidadDeRepeticiones){
                cantidadDeRepeticiones = recuento;
                caracterMasRepetido = caracter;
            }

        }
        
        System.out.println("El caracter que m�s se repite "
                + "sin contar los espacios. Es:\'"+caracterMasRepetido
                + "\' que se repite "+cantidadDeRepeticiones+" veces.");
        
        System.out.println("*** Funciones y Procedimientos ***");
        
        /*
        Las funciones y procedimientos son un bloque de c�digo
        que contienen una o m�s instrucciones, al cual podemos
        invocar para que sean ejecutadas. Las funciones y los
        procedimientos nos van a ayudar a hacer nuestro c�digo
        m�s legible y evitar c�digo duplicado.
        */
        
        /*
        Los m�todos de tipo funci�n siempre retornan un valor.
        En su declaraci�n deben indicar qu� tipo de valor retornan.
        En su cuerpo deben contener la sentencia 'return' con el
        retorno del tipo de dato que se indic� en su cabecera.
        */
        System.out.println("** Funciones **");
        int nro1 = retornarNumeroDiez();
        System.out.println(nro1);
        
    } // final del m�todo main
    
    //ejemplos de funciones
    public static int retornarNumeroDiez(){
        return 10;  //el return tiene que devolver
        //el mismo tipo de dato que se indica en la
        //firma del m�todo.
    }
    
} // final de la clase
