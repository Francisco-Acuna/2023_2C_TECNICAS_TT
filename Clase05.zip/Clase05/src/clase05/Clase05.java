/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase05;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        //método para extraer una subcadena
        String palabra = "Programación";
        //String es una clase que representa una cadena de caracteres
        //cada caracter ocupa un lugar de posición
        //las posiciones comienzan desde 0
        String subPalabra = palabra.substring(3);
        //el número que va dentro de los paréntesis indica la posición
        //desde donde se extraerá la sub-cadena
        System.out.println(subPalabra);

        String subPalabra2 = palabra.substring(5, 8);
        //en este caso indicamos desde dónde y hasta dónde queremos
        //extraer la sub-cadena
        System.out.println(subPalabra2);

        String palabra1 = "cuesta";
        String palabra2 = "subir";
        String palabra3 = "la";
        String palabra4 = "a";
        String palabra5 = "e";
        String palabra6 = "l";
        String palabra7 = "v";
        String palabra8 = "s";
        String palabra9 = "n";
        String palabra10 = "d";
        String palabra11 = "y";
        String palabra12 = "medio";

        System.out.println(palabra4.toUpperCase() + " "
                + palabra1.substring(0, 1).toUpperCase()
                + palabra1.substring(1));

        //Operadores aritméticos
        /*
        + suma
        - resta 
        * multiplicación
        / división
        % módulo o resto de la división
        Son operadores binarios porque necesitan 2 operandos.
        Los operandos son numéricos y el resultado es numérico
        */
        
        int nro1 = 10;
        int nro2 = 2;
        
        System.out.println("Suma");
        System.out.println(nro1 + nro2);
        
        System.out.println("Resta");
        System.out.println(nro1 - nro2);
        
        System.out.println("Multiplicación");
        System.out.println(nro1 * nro2);
        
        System.out.println("División");
        System.out.println(nro1 / nro2);
        
        System.out.println("Módulo o resto de la división");
        System.out.println(nro1 % nro2);
        
        //Operadores de asignación
        /*
        = igual (de asignación)
        += suma y asignación
        -= resta y asignación
        *= multiplicación y asignación
        /= división y asignación
        %= módulo y asignación
        Son operadores binarios.
        Asignan el valor a una variable y se la modifican utilizando una expresión
        */
        
        System.out.println(nro1); //nro1 vale 10
        nro1 = 12; //con el = se le asigna el valor que está a la derecha
        System.out.println(nro1);
        
        nro1 += 2; //sumo 2 al valor de la variable y le asigno ese valor
        //es lo mismo que: nro1 = nro1 + 2;
        System.out.println(nro1);
        
        nro1 -= 2; //resto 2 al valor de la variable y le asigno ese valor
        //es lo mismo que: nro1 = nro1 - 2;
        System.out.println(nro1);
        
        nro1 *= 2; //multiplico por 2 el valor de la variable y le asigno ese valor
        //es lo mismo que: nro1 = nro1 * 2;
        System.out.println(nro1);
        
        nro1 /= 2; //divido por 2 el valor de la variable y le asigno ese valor
        //es lo mismo que: nro1 = nro1 / 2;
        System.out.println(nro1);
        
        nro1 %= 2; //obtiene el módulo de la división entre la variable y el 2
        //y le asigna ese valor a la variable
        //es lo mismo que: nro1 = nro1 % 2;
        System.out.println(nro1);
        
        //Operadores incrementales y decrementales
        /*
        ++ incrementa el valor en 1
        -- decrementa el valor en 1
        Son operadores unarios, trabajan con un solo operador.
        */
        
        nro1 ++; //incrementa en 1 el valor de la variable
        //es lo mismo que: nro1 = nro1 + 1; o lo mismo que: nro1 += 1;
        System.out.println(nro1);
        
        nro1 --; //decrementa en 1 el valor de la variable
        //es lo mismo que: nro1 = nro1 - 1; o lo mismo que: nro1 -= 1;
        System.out.println(nro1);
        
        //Operadores relacionales
        /*
        > mayor
        < menor
        >= mayor o igual
        <= menor o igual
        == igual
        != distinto
        Son operadores binarios.
        Los operandos son numéricos y el resultado es booleano
        */
        
        nro1 = 15;
        nro2 = 20;
        
        System.out.println(nro1 > nro2); //false
        System.out.println(nro1 < nro2); //true
        System.out.println(nro1 >= nro2); //false
        System.out.println(nro1 <= nro2); //true
        System.out.println(nro1 == nro2); //false (está comparando con el == )
        System.out.println(nro1 != nro2); //true
        
    }

}
