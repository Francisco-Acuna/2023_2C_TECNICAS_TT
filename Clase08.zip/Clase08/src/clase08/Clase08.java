/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase08;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase08 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println("** String **");
        //la clase String contiene un vector de caracteres
        //podemos crear un objeto de la clase String de varias maneras:
        String texto1 = "Cadena de Texto!";
        String texto2 = new String("hola");
        String texto3 = "hola";
        
        //métodos para comparar
        //al comparar Strings con el operador == va a comparar que sean el
        //mismo objeto en memoria
        System.out.println(texto2 == "hola"); //false
        
        //Para comparar cadenas de caracteres teniendo en cuenta
        //su contenido, se utilizan los siguientes métodos:
        //.equals() .equalsIgnoreCase()
        System.out.println(texto2.equals("hola")); //true
        //.equals() compara literalmente las cadenas
        System.out.println(texto2.equals("HOLA")); //false
        //.equalsIgnoreCase() ignora las minúsculas y mayúsculas
        System.out.println(texto2.equalsIgnoreCase("HOLA")); //true
        
        //.contains()
        //devuelve un booleano que indica si contiene la subcadena
        System.out.println(texto1.contains("hola")); //false
        System.out.println(texto2.contains("hola")); //true
        
        //.length()
        //devuelve la longitud del vector, es decir, cuántos 
        //caracteres tiene
        System.out.println(texto1.length()); //16
        System.out.println(texto2.length()); //4
        
        //.isEmpty()
        //indica si la cadena está vacía, es decir,
        //si su longitud es igual a 0
        System.out.println(texto1.isEmpty()); //false
        
        //.isBlank() aparece a partir de JDK 11
        //indica si una cadena está vacía o en blanco.
        //por ejemplo, si sólo contiene espacios,
        //tabulaciones y/o saltos de línea
        String texto4 = "    ";
        System.out.println(texto4.isEmpty()); //false
        System.out.println(texto4.isBlank()); //true
        
        //.charAt()
        //devuelve el caracter del índice dado
        System.out.println(texto1.charAt(3));
        System.out.println(texto2.charAt(3));
        
        //.indexOf()
        //devuelve el índice de la primera ocurrencia
        //de la subcadena, si no la encuentra, devuelve -1
        System.out.println(texto1.indexOf("texto")); //-1
        System.out.println(texto1.indexOf("Texto"));
        //devuelve 10, es el índice en donde comienza
        //la subcadena
        
        //.trim()
        //quita los espacios de adelante y atrás
        texto3 = "  buenas noches   ";
        System.out.println(texto3);
        System.out.println(texto3.trim());
        
        //.startsWith() .endsWith()
        //devuelve un booleano si la cadena comienza o
        //finaliza con un texto determinado
        System.out.println(texto1.startsWith("hola"));//false
        System.out.println(texto2.startsWith("hola"));//true
        System.out.println(texto1.endsWith("exto"));//false
        System.out.println(texto1.endsWith("exto!"));//true
        
        //Métodos para realizar reemplazos
        //.replace()
        //reemplaza un caracter por otro
        System.out.println(texto1.replace('e', 'i'));
        //reemplaza una cadena por otra
        System.out.println(texto1.replace("Texto!", "caracteres."));
        //.replaceFirst()
        //reemplaza solo la primera vez que aparezca la cadena
        texto3 = "manzana, manzana, naranja";
        System.out.println(texto3.replaceFirst("manzana", "banana"));
        //.replaceAll()
        //reemplaza todas las veces que aparezca la cadena
        System.out.println(texto3.replaceAll("manzana", "banana"));
        //si bien .replace() también reemplaza todas las veces que 
        //aparece la cadena, el .replaceAll() es más potente, nos
        //permite buscar y reemplazar patrones de expresiones regulares
        //una expresión regular es una secuencia de caracteres que
        //definen un patrón de búsqueda
        
        //.repeat() aparece a partir del JDK 11
        //repite la cadena la cantidad de veces que se indique
        System.out.println(texto2.repeat(3));
        
        //anteriormente
    }
    
}
