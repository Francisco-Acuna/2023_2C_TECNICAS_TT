
package curso.tecnicas.teoria;


public class Clase26 {

    public static void main(String[] args) {
        /*
            INTERFAZ GR�FICA EN JAVA
        
        AWT (Abstract Windows Toolkit) - SWING - JavaFX
        
        En Java existen muchas interfaces gr�ficas y se pueden agregar
        m�s de forma externa.
        La primera en aparecer dentro del lenguaje fue AWT. Era una 
        interfaz gr�fica muy sencilla y veloz, estaba incluida dentro de la
        librer�a standard de Java. Pero el mayor problema lo ten�a en que
        no se ve�a igual en todos los SO. Luego con el tiempo apareci� SWING.
        
        SWING utiliza AWT, pero garantiza que su aspecto sea igual en todos
        los SO.
        
        A partir del JDK 5 o 6, aparece Java FX que en la versi�n de JDK 7 
        comienza a formar parte del n�cleo de Java. A partir del JDK 10 dej�
        de ser parte integral de la plataforma, ya no se incluye en el JDK 
        standard de Oracle.
        */
    }
    
}
