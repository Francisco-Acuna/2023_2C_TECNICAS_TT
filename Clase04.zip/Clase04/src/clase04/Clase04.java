/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase04;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Operador de concatenación
        String nombre = "Marcelo";
        String apellido = "López";
        
        System.out.println(nombre + " " + apellido);
        System.out.println("El nombre es: " + nombre);
        
        
        //pasar String a mayúsculas
        //toUpperCase()
        System.out.println(nombre.toUpperCase());
        //imprime la variable en mayúscula
        //pero la variable sigue igual
        System.out.println(nombre);
        //modificar la variable
        nombre = nombre.toUpperCase();
        System.out.println(nombre);
        
        //pasar String a minúsculas
        //toLowerCase()
        System.out.println(nombre.toLowerCase());
        //imprime la variable en minúscula
        //pero la variable sigue igual
        System.out.println(nombre);
        nombre = nombre.toLowerCase();
        System.out.println(nombre); 
        
        
    }
    
}
