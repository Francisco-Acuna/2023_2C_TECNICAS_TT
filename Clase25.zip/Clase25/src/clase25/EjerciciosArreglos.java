

package clase25;

import java.util.Scanner;


public class EjerciciosArreglos {
    public static void main(String[] args) {
        
        /*
        Ejercicios 01
        Crear un vector que contenga el monto de la facturaci�n total
        de una empresa de los �ltimos 6 meses.
        Informar:
        - La m�xima facturaci�n
        - La facturaci�n m�s baja
        - El promedio de la facturaci�n        
        */
        
//        
//        float[] facturaciones = {5483.25f, 4568.74f, 
//            1852.55f, 6942.82f, 4753.84f, 9562.35f};
//        
//        float maximaFacturacion = Float.MIN_VALUE;
//        for(float f:facturaciones) 
//            if(f>maximaFacturacion) maximaFacturacion=f;
//        
//        float minimaFacturacion = Float.MAX_VALUE;
//        for(float f:facturaciones) 
//            if(f<minimaFacturacion) minimaFacturacion=f;
//        
//        float suma = 0;
//        for(float f:facturaciones) suma +=f;
//        
//        System.out.println("La m�xima facturaci�n es: "+maximaFacturacion);
//        System.out.println("La m�nima facturaci�n es: "+minimaFacturacion);
//        System.out.println("El promedio de la facturaci�n es: "
//                +(suma/facturaciones.length));
        
        /*
        Ejercicios 02
        Crear un vector de enteros de 10 posiciones.
        Pedirle al usuario que cargue 10 valores para ese vector.
        Mostrar con foreach el listado de n�meros que ingres�.
        Mostrar la suma de todos los elementos.
        Mostrar el promedio.
        Indicar cu�ntos n�meros pares hay en el arreglo.
        Indicar cu�ntos n�meros impares hay en el arreglo.
        Indicar cu�ntas veces se repite el n�mero 2.
        Resolver todo dentro de un m�todo que sea invocado dentro del main.
        */
        
        resolverEjercicio2();
       
        
    }
    
    public static void resolverEjercicio2(){
        int[] arreglo = crearArreglo();
        System.out.println("Contenido del arreglo:");
        for(int a:arreglo) System.out.println(a);
        System.out.println("La suma de todos los elementos es "
                + "igual a: "+sumarContenidoDelArreglo(arreglo));
        System.out.println("El promedio del arreglo es: "
                +obtenerPromedioDelArreglo(arreglo));
        System.out.println("El arreglo tiene "+contadorDePares(arreglo)+" pares");
        System.out.println("El arreglo tiene "+contadorDeImpares(arreglo)+" impares");
        System.out.println("El n�mero \'2\' se repite "+contadorDeNumeros(2, arreglo)+" vez/veces");
    }
    
    public static int[] crearArreglo(){
        Scanner teclado = new Scanner(System.in);
        System.out.println("�Cu�ntos elementos quiere guardar?");
        int longitud = teclado.nextInt();
        int[] arreglo = new int[longitud];
        System.out.println("Por favor ingrese los "+longitud+" valores:");
        for (int i=0; i<arreglo.length; i++) {
            System.out.print("Ingrese el valor "+(i+1)+" - ");
            arreglo[i] = teclado.nextInt();
        }
        return arreglo;        
    }
    
    public static int sumarContenidoDelArreglo(int[] arreglo){
        int suma = 0;
        for(int a:arreglo) suma+=a;
        return suma;
    }
    
    public static int obtenerPromedioDelArreglo(int[] arreglo){
        int promedio = sumarContenidoDelArreglo(arreglo) / arreglo.length;
        return promedio;
    }
    
    public static int contadorDePares(int[] arreglo){
        int cantidadDePares = 0;
        for(int a:arreglo) if(a%2==0) cantidadDePares++;
        return cantidadDePares;
    }
    
    public static int contadorDeImpares(int[] arreglo){
        int cantidadDeImpares = 0;
        for(int a:arreglo) if(a%2!=0) cantidadDeImpares++;
        return cantidadDeImpares;
    }
    
    /**
     * Este m�todo pide un n�mero entero por par�metro 
     * para contarlo cu�ntas veces aparece dentro de un arreglo
     * @param numero es el n�mero que queremos contar cu�ntas veces aparece
     * @param arreglo es el vector de n�meros enteros en el cual voy a buscar 
     * el n�mero ingresado por par�metro
     * @return el retorno es un n�mero entero que indica la cantidad de veces 
     * que apareci� el n�mero ingresado por par�metro
     */
    public static int contadorDeNumeros(int numero, int[] arreglo){
        int contador = 0;
        for(int a:arreglo) if(a==numero) contador++;
        return contador;
    }
    
}
