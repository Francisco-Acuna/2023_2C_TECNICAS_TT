

package objetosclase1.entidades;


public class Auto {
    //atributos de la clase
    //son las caracter�sticas, es decir, lo que tiene.
    public String marca;
    public String modelo;
    public String color;
    public int velocidad;
    
    //el m�todo constructor es el encargado de crear un objeto de la clase
    //si no declaramos ning�n m�todo constructor, se crea uno vac�o por defecto
    public Auto(){} // crea un auto sin estado
    
    //sobrecarga de constructores:

    public Auto(String marca, String modelo, String color, int velocidad) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.velocidad = velocidad;
    }

    public Auto(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.velocidad = 0;
    }

    public Auto(String modelo, String color) {
        this.marca = "Ford";
        this.modelo = modelo;
        this.color = color;
        this.velocidad = 0;
    }
    
    
    
    //m�todos de la clase
    //son las acciones, es decir, lo que puede hacer
    public void acelerar(){
        velocidad += 10;
    }
    
    public void frenar(){
        velocidad -= 10;
    }
    
    
}
