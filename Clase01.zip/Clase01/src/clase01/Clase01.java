/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase01;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Hola Mundo!!");
        
        //Comentarios
        
        //comentario en línea (//)
        //si quiero seguir escribir debajo, debo agregar las //
        
        /*
        esto es un bloque
        de comentarios
        Podemos escribir 
        en varias líneas
        */
        
        
        /**
         * Este es un comentario JavaDoc
         * se puede escribrir en líneas
         * se utiliza para documentar
         * clases, interfaces, métodos
         */
        
        //sout + tab (atajo de teclado para imprimir por consola)
        System.out.println("Hello World!");
        //esto es una sentencia
        //una sentencia es una orden que se le da al programa para que 
        //realice una tarea específica
        //las sentencias finalizan con ;
        //los ; separan una sentencia de otra
        
        //impresión con salto de línea
        System.out.println("1");
        System.out.println("2");
        System.out.println("3");
        System.out.println("4");
        System.out.println("5");
        
        //impresión sin salto de línea
        System.out.print("1");
        System.out.print("2");
        System.out.print("3");
        System.out.print("4");
        System.out.print("5");
        
        System.out.println("");
        
        
        
    }
    
}
