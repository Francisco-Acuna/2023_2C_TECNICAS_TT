/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase10;

import java.util.Scanner;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*
        Solicitar al usuario que ingrese 3 números.
        Luego informar:
        a) La suma de los dos primeros
        b) La resta de los dos segundos
        c) El resto entre el primero y el segundo
        d) La suma total
        e) El promedio
        */
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Por favor, ingrese 3 números enteros.");
        System.out.println("A continuación ingrese el primero y luego presione enter:");
        int num1 = teclado.nextInt();
        System.out.println("A continuación ingrese el segundo y luego presione enter:");
        int num2 = teclado.nextInt();
        System.out.println("A continuación ingrese el tercero y luego presione enter:");
        int num3 = teclado.nextInt();
        
        int suma = num1 + num2;
        int resta = num2 - num3;
        
        
        System.out.println("La suma de los dos primeros números es "+suma);
    }
    
}
