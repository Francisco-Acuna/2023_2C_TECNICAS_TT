/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase12;

import java.util.Scanner;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*
        Solicitar al usuario que ingrese 3 números.
        Luego informar:
        a) La suma de los dos primeros
        b) La resta de los dos segundos
        c) El resto entre el primero y el segundo
        d) La suma total
        e) El promedio
        */
        
        Scanner teclado = new Scanner(System.in);
        
//        System.out.println("Por favor, ingrese 3 números enteros.");
//        System.out.println("A continuación ingrese el primero y luego presione enter:");
//        int num1 = teclado.nextInt();
//        System.out.println("A continuación ingrese el segundo y luego presione enter:");
//        int num2 = teclado.nextInt();
//        System.out.println("A continuación ingrese el tercero y luego presione enter:");
//        int num3 = teclado.nextInt();
//        
//        int suma = num1 + num2;
//        int resta = num2 - num3;
//        int resto = num1 % num2;
//        int total = suma + num3;
//        int promedio = total / 3;
        
//        System.out.println("La suma de los dos primeros números es "+suma);
//        System.out.println("La resta de los dos segundos números es "+resta);
//        System.out.println("El resto del primer y segundo número es "+resto);
//        System.out.println("La suma total es de "+total);
//        System.out.println("El promedio es de "+promedio);
        
        
        /*
        Solicitar al usario que ingrese dos números.
        Devolver el primer número aumentado en 17
        y el segundo número decrementado en 10
        */
        
//        System.out.println("Por favor, ingrese dos números enteros (sin decimales)");
//        System.out.println("A continuación ingrese el primer número y presione enter:");
//        num1 = teclado.nextInt();
//        System.out.println("A continuación ingrese el segundo número y presione enter:");
//        num2 = teclado.nextInt();
        
//        int aumento = num1 + 17;
//        int decremento = num2 - 10;
        
//        System.out.println("El primer número es "+num1);
//        System.out.println("El primer número aumentado en 17 es "+aumento);
//         num1 += 17;
//         num2 -= 10;
//         
//         System.out.println("El primer número aumentado /nen 17 es "+num1);
//         System.out.println("El primer número decrementado en 10 es "+num2);
        
         /*
        Solicitar al usuario que ingrese la base y la altura de un rectángulo e informar:
        El área del rectángulo
        El perímetro del rectángulo.
        */
         
//         System.out.println("Por favor, ingrese la base de un rectángulo y luego presione enter:");
//         double base = teclado.nextDouble();
//         System.out.println("Ingrese la altura y presione enter:");
//         double altura = teclado.nextDouble();
//         
//         double area = base * altura;
//         double perimetro = (base + altura) * 2;
//         
//         System.out.println("El área del rectángulo es: "+area);
//         System.out.println("El perímetro del rectángulo es: "+perimetro);
         
        /*
        Solicitar al usuario que ingrese el radio de un círculo en informar el área
        */
         
        System.out.println("Por favor, ingrese el radio del círculo y presione enter:");
        double radio = teclado.nextDouble();
        
        //final double PI = 3.14;
        //double areaCirculo = PI * (radio * radio);
        double areaCirculo = Math.PI * Math.pow(radio,2);
        System.out.println("El área del círculo es: "+areaCirculo);
        System.out.println("*******************");
        System.out.println(Math.PI);
        System.out.println("*******************");
        
        /* Se pide que ingrese por consola dos párrafos y muestre por pantalla lo siguiente:
            1. Los párrafos, ¿son iguales con el operador relacional ==?
            2. Los párrafos, ¿poseen el mismo contenido? Sin importar si están en mayúsculas o
            minúsculas.
            3. Mostrar los párrafos en mayúsculas.
            4. Mostrar los párrafos en minúsculas.
            5. Mostrar la primera letra en mayúscula de cada párrafo.
            6. Unir los párrafos con una coma.
        */
        
        teclado.nextLine();
        System.out.println("Por favor, ingrese dos párrafos.");
        System.out.println("A continuación ingrese el primero y presione enter:");
        String parrafo1 = teclado.nextLine();
        System.out.println("Por favor ingrese el segundo párrafo y presione enter:");
        String parrafo2 = teclado.nextLine();
        
        boolean comparacionParrafo = parrafo1 == parrafo2;
        
        System.out.println("La comparación entre ambos párrafos con el operador de == es: "+comparacionParrafo);
        
        comparacionParrafo = parrafo1.equalsIgnoreCase(parrafo2);
        System.out.println("La comparación entra ambos párrafos teniendo "
                + "en cuenta su contenido sin importar las minúsculas"
                + " ni las mayúsculas es: "+comparacionParrafo);
        
        System.out.println("El primer párrafo en mayúscula es: "+parrafo1.toUpperCase());
        System.out.println("El segundo párrafo en mayúscula es: "+parrafo2.toUpperCase());
        
        System.out.println("El primer párrafo en minúsculas es: "+parrafo1.toLowerCase());
        System.out.println("El segundo párrafo en minúsculas es: "+parrafo2.toLowerCase());
        
        String primeraMayuscula = parrafo1.substring(0,1).toUpperCase() + parrafo1.substring(1).toLowerCase();
        System.out.println("El primer párrafo con la primera letra en mayúscula es: "+primeraMayuscula);
        primeraMayuscula = parrafo2.substring(0,1).toUpperCase() + parrafo2.substring(1).toLowerCase();
        System.out.println("El segundo párrafo con la primera letra en mayúscula es: "+primeraMayuscula);
    
        System.out.println("A continuación se presentan ambos párrafos unidos con una coma:");
        System.out.println(parrafo1 + ", " + parrafo2);
        
        /*Crear un programa que solicite al usuario que ingrese su primer nombre y 
        su apellido de una sola vez.
        Luego mostrarlo por consola, por separado, indicando cuál es su apellido primero
        y luego debajo entre comillas dobles, su nombre
        Nombre y apellido deben ir con la primer letra en mayúscula
        */
        
        System.out.println("Ingrese su primer nombre y su apellido de una vez. Separados por un espacio."
                + "Luego presione enter:");
        String nombreApellido = teclado.nextLine();
        
        int espacio = nombreApellido.indexOf(" ");
        
        String nombre = nombreApellido.substring(0,espacio);
        String apellido = nombreApellido.substring(espacio+1);
        
        nombre = nombre.substring(0,1).toUpperCase() + nombre.substring(1).toLowerCase();
        apellido = apellido.substring(0,1).toUpperCase() + apellido.substring(1).toLowerCase();
        
        System.out.println("Su apellido es: "+apellido);
        System.out.println("Su nombre es: \""+nombre+"\"");
        
    }
    
    
}
