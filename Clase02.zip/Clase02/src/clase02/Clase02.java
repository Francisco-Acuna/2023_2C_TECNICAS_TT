/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase02;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here 
                
        //Variables
        
        int a; //declaración de variable con un tipo de dato (int)
        //y un nombre o identificador (a)
        a = 2; //asigno valor a la variable
        System.out.println(a);
        a = 4; //cambio el valor de la variable
        System.out.println(a);
        int b = 3; //declaración y asignación en línea
        //a = "hola"; error, no puedo asignar otro tipo de dato
        
        //una variable tiene una única declaración
        //e innumerables valores
        
        int c=12, d=23, e=41; //declaración y asignación múltiple en línea
        
        //Tipos de datos primitivos
        
        //byte - ocupa 1 byte y representa un número entero
        //entre -128 y 127
        byte f = 100;
        System.out.println(f);
        //f = -160; error, no puedo excederme de los límites
        
        //short - ocupa 2 bytes y representa un entero
        //entre -32.768 y 32.767
        short g = 32500;
        System.out.println(g);
        
        //int - ocupa 4 bytes y representa un entero 
        //entre -2.147.483.648 y 2.147.483.647
        int h = 2140489655;
        System.out.println(h);
        
        //long - ocupa 8 bytes y representa un valor entero
        //es un valor muy grande no tan utilizado
        long i = 1234567890123L; //debe llevar una L al final
        //por convención utilizamos la L mayúscula
        System.out.println(i);
        
        
        //float - ocupa 4 bytes y tiene una precisión de 32 bits
        float j = 14.25f; //debemos agregar una f al final de la literal
        //el punto separa los decimales, no se utiliza la coma
        System.out.println(j);
        
        //double - ocupa 8 bytes y tiene una precisión de 64 bits
        double k = 56.56; //no necesita agregarse ninguna letra
        System.out.println(k);
        
        //diferencia de precisión entre float y double
        float fl = 100f;
        double dl = 100;
        System.out.println(fl / 3);
        System.out.println(dl / 3);
        
        
        
    }
    
}
