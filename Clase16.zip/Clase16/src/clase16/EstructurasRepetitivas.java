

package clase16;


public class EstructurasRepetitivas {
    public static void main(String[] args) {
        
        //bucles - estructuras repetitivas
        System.out.println("**Estructura while**");
        
        //la estructura while, evalúa una condición y mientras sea
        //verdadera, ejecuta las sentencias del cuerpo del while
        
        //imprimir los números del 1 al 10 uno debajo del otro.
        int contador = 1;
        
        while(contador <= 10){
            System.out.println(contador);
            contador++;
        }
        
        contador = 1;
        //ERROR - bucle infinito
//        while (contador <= 10) {
//            System.out.println(contador);
//        }
        
//        while (contador >= 1) {
//            System.out.println(contador);
//            contador++;
//        }
        
        
        
        
    }
}
