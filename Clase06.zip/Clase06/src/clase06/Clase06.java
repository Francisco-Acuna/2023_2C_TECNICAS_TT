/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase06;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase06 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Tabla de verdad
        //Es una representación lógica de resultados
        /*
        A   |   B   |   AND |   OR
        V   |   V   |   V   |   V
        V   |   F   |   F   |   V
        F   |   V   |   F   |   V
        F   |   F   |   F   |   F
        El AND siempre es falso a menos que todos sus términos sean verdaderos
        El OR siempre es verdadero, a menos que todos sus términos sean falsos
        
        Negación (NOT)
        A   NOT
        V   F
        F   V
        
        */
        
        //Operadores lógicos
        /*
        & AND (y lógico)
        | OR (o lógico)
        ! NOT (negación)
        Los operandos son booleanos.
        El resultado es booleano.
        */
        
        boolean log1 = true;
        boolean log2 = false;
        
        System.out.println("AND &&:");
        System.out.println(log1 && log2); //false
        
        System.out.println("OR ||:");
        System.out.println(log1 || log2); //true
        
        System.out.println("NOT !");
        System.out.println(!log1); //false
        System.out.println(!log2); //true
        
        //Al utilizar un solo operador, se evaluarán todas las condiciones
        //Al utilizar dos operadores (&& ||), si con la primer condición
        //se determina el valor de verdad, no evalúa las siguientes.
        
    }
    
}
