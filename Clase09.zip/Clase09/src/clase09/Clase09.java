/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase09;

import java.util.Scanner;


/**
 *
 * @author Aula 8 - Docente
 */
public class Clase09 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //caracteres de escape
        //son secuencias especiales de caracteres que se utilizan
        //en cadenas de texto y literales de caracteres para
        //representar caracteres especiales o caracteres que no se
        //pueden representar directamente.
        //Los caracteres de escape comienzan con una barra invertida
        //(\) seguida de un caracter que indica qué tipo de escape
        //estamos utilizando
        //Algunos ejemplos:
        
        // \n salto de línea
        System.out.println("Hola\nMundo!");
        
        // \t tabulación
        System.out.println("Hola\tMundo!");
        
        // \" comillas dobles
        System.out.println("\"Hola Mundo!\"");
        
        // \' comillas simples
        System.out.println("\'Hola Mundo\'");
        
        // \\ barra invertida
        System.out.println("\\Hola Mundo!\\");
        
        System.out.println("\n** Clase System **");
        
        /*la clase System es un intermediario entra la JVM
        y el entorno de ejecución en que estamos ejecutando
        nuestro programa.
        Como la máquina virtual de Java puede ejecutarse en 
        múltiples plataformas, la clase System nos abstrae de 
        la plataforma sobre la que se está ejecutando.
        */
        
        /*
        Los atributos más clásicos con out, err, in
        representan streams de entrada y salida.
        Son atributos finales y estáticos.
        out es un stream de salida sincronizado
        err es un stream de salida desincronizado
        in es un stream de entrada sincronizado
        */
        
        /*
        "stream" (flujo o corriente), es una secuencia de datos
        que se procesa o transmite de manera secuencial, en lugar
        de cargarse o procesarse en su totalidad antes de usarse.
        */
        
        System.out.println("Hola 1");
        System.out.println("Hola 2");
        System.out.println("Hola 3");
        System.out.println("Hola 4");
        System.out.println("Hola 5");
        System.out.println("Hola 6");
        System.out.println("Hola 7");
        System.out.println("Hola 8");
        System.out.println("Hola 9");
        System.out.println("Hola 10");
        System.out.println("Hola 11");
        System.out.println("Hola 12");
        System.out.println("Hola 13");
        System.out.println("Hola 14");
        System.out.println("Hola 15");
        System.out.println("Hola 16");
        System.out.println("Hola 17");
        System.out.println("Hola 18");
        System.out.println("Hola 19");
        System.out.println("Hola 20");
        
        System.err.println("Ocurrió un error!");
        //err es desincronizado por lo que puede aparecer
        //en cualquier lugar
        
        //.exit()
        //cierra el runtime, es decir, que finaliza el programa
//        System.out.println("Ejecuto el método exit()");
//        System.exit(0);
//        System.out.println("Esta sentencia no se ejecuta.");
        //el parámetro 0 indica que no hubo error al terminar el programa
        //el parámetro 1 indica que hubo error al terminar el programa
        
        //diccionario getenv()
        //este método devuelve un diccionario de propiedades del entorno
        //de ejecución, es decir, propiedades del sistema. Que varían
        //según el SO y la versión de Java
        System.out.println("\ngetenv()");
        System.out.println(System.getenv());
        
        //el .getProperties() representa un mapa o vector asociativo
        //que es igual en todas las configuraciones
        System.out.println(System.getProperties()); //propiedades del sistema
        System.out.println(System.getProperty("os.name")); //nombre del SO
        System.out.println(System.getProperty("os.version")); //versión del SO
        System.out.println(System.getProperty("os.arch")); //arquitectura (32 o 64 bits)
        System.out.println(System.getProperty("java.version")); //versión de Java
        System.out.println(System.getProperty("user.name")); //nombre de usuario de SO
        System.out.println(System.getProperty("user.home")); //directorio del usuario
        
        System.out.println("\n** Clase Scanner **");
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Ingrese su nombre:");
        String nombre = teclado.next();
        System.out.println("Hola, tu nombre es: "+nombre);
        
        
        
        
    }
    
}
