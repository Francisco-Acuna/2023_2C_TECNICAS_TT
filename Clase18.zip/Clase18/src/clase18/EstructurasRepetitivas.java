

package clase18;

import java.util.Random;
import java.util.Scanner;


public class EstructurasRepetitivas {
    public static void main(String[] args) {
        
        //bucles - estructuras repetitivas
        System.out.println("**Estructura while**");
        
        //la estructura while, evalúa una condición y mientras sea
        //verdadera, ejecuta las sentencias del cuerpo del while
        
        //imprimir los números del 1 al 10 uno debajo del otro.
        int contador = 1;
        
        while(contador <= 10){
            System.out.println(contador);
            contador++;
        }
        
        contador = 1;
        //ERROR - bucle infinito
//        while (contador <= 10) {
//            System.out.println(contador);
//        }
        
//        while (contador >= 1) {
//            System.out.println(contador);
//            contador++;
//        }
        
        System.out.println("** Estructura do-while **");
        
        //La estructura do-while ejecuta al menos una vez las sentencias
        //y luego evalúa la condición para seguir ejecutando
        
        //sumamos los números positivos ingresados por teclado
        int numero = 0;
        int suma = 0;
        Scanner teclado = new Scanner(System.in);
        
//        do{
//            System.out.println("Ingrese un número entero para sumar"
//                    + " ó 0 para salir");
//            numero = teclado.nextInt();
//            if(numero>0) suma+=numero;
//        }while(numero!=0);
//        
//        System.out.println("Usted ingresó un 0 para salir.");
//        System.out.println("La suma de los números enteros positivos"
//                + " es de: "+suma);
        
        System.out.println("** Sentencia break **");
        
        //La sentencia break genera un corte en la secuencia
        //de comandos y saca la ejecución del bloque de código
        
        //siguiendo el ejemplo anterior, si la suma supera
        //los 100, vamos a cortar la ejecución.
//        suma=0;
//        do{
//            System.out.println("Ingrese un número entero para sumar"
//                    + " ó 0 para salir");
//            numero = teclado.nextInt();
//            if(numero>0) suma+=numero;
//            if(suma>100) break;
//        }while(numero!=0);
        
        System.out.println("La suma de números enteros "
                + "positivos es de: "+suma);
        
       
        System.out.println("** Sentencia continue **");
        
        //La sentencia continue genera un corte en la secuencia
        //de comandos y vuelve al comienzo del bucle
        
        //continuando con nuestro ejemplo, ahora sólo sumaremos
        //los números pares
        suma=0;
//        do{
//            System.out.println("Ingrese un número entero para sumar"
//                    + " ó 0 para salir");
//            numero = teclado.nextInt();
//            if(numero%2!=0) continue;
//            if(numero>0) suma+=numero;
//            if(suma>100) break;
//        }while(numero!=0);
//        
//        System.out.println("La suma de números enteros positivos pares es de: "+suma);
        
        System.out.println("** Estructura for **");
        
        //La estructura for es una estructura repetitiva
        
        //imprimir los números del 1 al 10 uno debajo del otro
        
        for(int i=1; i<=10; i++){
            System.out.println(i);
        }
        
        System.out.println("***********************");
        
        //si sólo ejecutamos una instrucción del for,
        //lo podemos hacer en línea
        for(int i=1; i<=10; i++) System.out.println("Hola Mundo!!");
        
        //La variable que está dentro del for es una variable local.
        //Sólo se utiliza dento del for, no tiene alcance (scope) fuera de
        //la estructura. Al terminar el bucle for, desaparece. Se 
        //destruye y deja de ocupar lugar en memoria.
        
        System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&");
        //imprimir los números del 1 al 10
        //sin imprimir los números 2, 5 y 9
        for(int i=1; i<=10; i++){
            if(i!=2 && i!=5 && i!=9) System.out.println(i);
        }
        
        
        //imprimir los números del 1 al 30 sin imprimir los números
        //entre el 10 y el 20
        System.out.println("--------------");
        for(int i=1; i<=30; i++){
            //if(!(i>=10 && i<=20)) System.out.println(i);
            if(i<10 || i>20) System.out.println(i);
        }
        
        //imprimir los números del 1 al 10 salteando de a 2
        //uno al lado del otro
        System.out.println("--------------");
        for(int i=1; i<=10; i+=2){
            System.out.print(i);
        }
        System.out.println("");

        //imprimir los números del 1 al 20
        //que sean pares
        //uno al lado del otro, separados con barra invertida
        for(int i=1; i<=20; i++){
            if(i%2==0) System.out.print(i+"\\");
        }
        System.out.println("");
        
        /*
        Crear una aplicación que valide el ingreso a una
        plataforma Online Banking a través de una clave Token.
        
        Se debe tener en cuenta lo siguiente:
        * La Clave Token debe ser un número aleatorio
        de 6 dígitos.
        * El cliente debe ingresar los campos Usuario,
        Contraseña y Clave Token (todos obligatorios).
        * El campo Usuario no distingue minúsculas
        o mayúsculas.
        * El campo Contraseña es sensible a las
        minúsculas y mayúsculas.
        * La clave Token aleatoria se le informa al usuario al 
        pedirle que ingrese las credenciales.        
        * El cliente solo posee 3 intentos de logueo. Si
        alcanza los 3 intentos fallidos de forma
        consecutiva, la aplicación deberá informar al
        usuario que debe dirigirse a la sucursal del
        banco más cercana para poder desbloquear
        sus credenciales.
        * Por cada intento fallido, la aplicación debe
        preguntar al cliente si desea continuar
        colocando las credenciales de manera
        correcta.
        * Si el cliente coloca las credenciales de forma
        correcta, deberá informar que ha ingresado
        correctamente al Online Banking.
        */
        
        Random random = new Random();
        //la clase Random se utiliza para generar números aleatorios
        
        String usuario = "Pepito";
        String clave = "ClavePepito1234";
        int token = random.nextInt(1000000); // esto devuelve entre el 000000 y el 999999
        //el método nextInt() de la clase Random, indica los números aleatorios
        //que se pueden representar. Se toma el número ingresado como parámetro
        //menos 1. Va desde el 0 hasta el 999999 en este caso.
        int intentos = 0;
        
        while(intentos<3){
            //al momento de pedirle las credenciales al usuario
            //le mostramos la clave token autogenerada
            System.out.println("*** LA CLAVE TOKEN ES "+token+" ***");
            System.out.println("Ingrese su usuario:");
            String usuarioIngresado = teclado.nextLine();
            
            System.out.println("Ingrese su contraseña:");
            String claveIngresada = teclado.nextLine();
            
            System.out.println("Ingrese la clave Token:");
            int tokenIngresado = teclado.nextInt();
            //consumimos el salto de línea
            teclado.nextLine();
            
            //si las 3 credenciales son correctas, el usuario ingresa 
            //al online banking
            if(usuarioIngresado.equalsIgnoreCase(usuario) 
                    && claveIngresada.equals(clave)
                    && tokenIngresado == token){
                System.out.println("*** Ingreso exitoso al Home Banking ***");
                break;
            }else{
                //si las credenciales no son correctas, se incrementa la
                //cantidad de intentos fallidos
                intentos++;
                //si no alcanzó los 3 intentos, le mostramos los siguientes mensajes
                if(intentos<3){
                    System.out.println("Credenciales incorrectas. Usted lleva "
                            +intentos+" intentos fallidos");
                    System.out.println("Recuerde que sólo tiene 3 intentos antes"
                            + "de que se bloqueen sus credenciales.");
                }
                //le preguntamos al usuario si quiere volver a intentar
                if(intentos<3){
                    String respuesta;
                    //utilizamos un do-while para asegurarnos de que la respuesta
                    //sea correcta
                    do {
                        System.out.println("Desea intentar nuevamente? SI/NO");
                        respuesta = teclado.nextLine().toUpperCase();
                        if(!respuesta.equals("SI") && !respuesta.equals("NO")){
                            System.out.println("Debe ingresar \'SI\' o \'NO\'");
                        }
                    } while (!respuesta.equals("SI") && !respuesta.equals("NO"));
                    
                    //si la respuesta es "NO", lo saca del sistema
                    if(respuesta.equals("NO")){
                        System.out.println("Gracias por utilizar nuestro servicio.");
                        break;
                    }
                }
            }
            if(intentos == 3){
                System.out.println("Ha alcanzado el límite de intentos fallidos.");
                System.out.println("*** CREDENCIALES BLOQUEADAS ***");
                System.out.println("Por favor diríjase a la sucursal del banco más "
                        + "cercana para desbloquear sus credenciales.");
            }
        }
        
        
        
    }
}
